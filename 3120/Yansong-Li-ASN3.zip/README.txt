To run the code:

1.complie: gcc -o A3 A3.c
2.run ./A3

Existing problem:
I used two gobal variables to calculate the total waiting time in psjf algorithm.
It declared as gobal variables because when I declare a array inside the PSJF() function, the output changes.
I cannot figure out the reason, so I have to use gobal varibles to prevent it.
It works fine.
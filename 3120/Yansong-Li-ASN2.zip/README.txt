To compile the code: gcc -pthread A2.c -o A2
To run the code: ./A2
To run the code:

1.complie: gcc -o prog prog.c
2.run ./prog

Existing problem:

 Sometimes. it requires input "exit" for several times to end the program.
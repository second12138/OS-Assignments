To run the code:

1.complie: gcc -o A4 A4.c
2.run ./A4